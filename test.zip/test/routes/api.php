<?php

// use App\Http\Controllers\AdminController;
// use Illuminate\Http\Request;

use App\Http\Controllers\AdsController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\AssingOrderController;
use App\Http\Controllers\BankDetailController;
use App\Http\Controllers\CountryController;
use App\Http\Controllers\DeleveryOrderController;
use App\Http\Controllers\HomePageController;
use App\Http\Controllers\ItemController;
use App\Http\Controllers\ItemTypeController;
use App\Http\Controllers\MessageController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\OrderDetailController;
use App\Http\Controllers\PostAdvertisementsController;
use App\Http\Controllers\QuestionController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\RiderController;
use App\Http\Controllers\SectionController;
use App\Http\Controllers\SellerController;
use App\Http\Controllers\SellerOrderController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\UserProfileController;
use App\Http\Controllers\VisitorSectionController;
use App\Models\UserProfile;
use Illuminate\Routing\Router;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });
//->middleware('auth:api');
Route::post('login', [ApiController::class, 'authenticate']);
Route::post('register', [ApiController::class, 'register']);

//-------------------------Admin----------------------------------

Route::post('savecountry', [CountryController::class, 'saveCountry']);
Route::get('showCountry/{id}', [CountryController::class, 'showCountry']);
Route::put('updateCountry/{id}', [CountryController::class, 'updateCountry']);
Route::delete('deleteCountry/{id}', [CountryController::class, 'deleteCountry']);

Route::post('sectionSave', [SectionController::class, 'sectionSave']);
Route::get('sectionshow/{id}', [SectionController::class, 'sectionshow']);
Route::put('sectionupdate/{id}', [SectionController::class, 'sectionupdate']);
Route::delete('sectiondelete/{id}', [SectionController::class, 'sectiondelete']);

Route::post('savebankdetail',[BankDetailController::class, 'saveBankdetail']);
Route::get('showbankdetail/{id}', [BankDetailController::class, 'showbankdetail']);
Route::put('updatebankdetail/{id}', [BankDetailController::class, 'updatebankdetail']);
Route::delete('deletebankdetail/{id}', [BankDetailController::class, 'deletebankdetail']);

Route::post('adsSave',[AdsController::class, 'adsSave']);
Route::get('adsshow/{id}', [AdsController::class, 'adsshow']);
Route::put('adsupdate/{id}', [AdsController::class, 'adsupdate']);
Route::delete('adsdelete/{id}', [AdsController::class, 'adsdelete']);

Route::post('savemessage', [MessageController::class, 'savemessage']);
Route::get('showmessage/{id}', [MessageController::class, 'showmessage']);
Route::put('updatemessage/{id}', [MessageController::class, 'updatemessage']);
Route::delete('deletemessage/{id}', [MessageController::class, 'deletemessage']);

Route::post('saveQuestion', [QuestionController::class, 'saveQuestion']);
Route::get('showQuestion/{id}', [QuestionController::class, 'showQuestion']);
Route::put('updateQuestion/{id}', [QuestionController::class, 'updateQuestion']);
Route::delete('deleteQuestion/{id}', [QuestionController::class, 'deleteQuestion']);

Route::post('saveSetting', [SettingController::class, 'saveSetting']);
Route::get('showSetting/{id}', [SettingController::class, 'showSetting']);
Route::put('updateSetting/{id}', [SettingController::class, 'updateSetting']);
Route::delete('deleteSetting/{id}', [SettingController::class, 'deleteSetting']);

//-----------------------------------------------------------------------

Route::post('saverider', [RiderController::class, 'saverider']);
Route::get('showstatus/{id}', [RiderController::class, 'showstatus']);
Route::put('updaterider/{id}', [RiderController::class, 'updaterider']);

Route::post('ItemTypeSave', [ItemTypeController::class, 'ItemTypeSave']);
Route::get('ItemTypeshow/{id}', [ItemTypeController::class, 'ItemTypeshow']);
Route::put('ItemTypeupdate/{id}', [ItemTypeController::class, 'ItemTypeupdate']);
Route::delete('ItemTypedelete/{id}', [ItemTypeController::class, 'ItemTypedelete']);

Route::post('ItemSave', [ItemController::class, 'ItemSave']);
Route::get('Itemshow/{id}', [ItemController::class, 'Itemshow']);
Route::put('Itemupdate/{id}', [ItemController::class, 'Itemupdate']);
Route::delete('Itemdelete/{id}', [ItemController::class, 'Itemdelete']);

Route::post('SellerSave', [SellerController::class, 'SellerSave']);
Route::get('Sellershow/{id}', [SellerController::class, 'Sellershow']);
Route::put('Sellerupdate/{id}', [SellerController::class, 'Sellerupdate']);

Route::post('savereview', [ReviewController::class, 'savereview']);
Route::get('showreview/{id}', [ReviewController::class, 'showreview']);
Route::put('updatereview/{id}', [ReviewController::class, 'updatereview']);
Route::delete('deletereview/{id}', [ReviewController::class, 'deletereview']);

Route::post('orderSave', [OrderController::class, 'orderSave']);
Route::get('ordershow/{id}', [OrderController::class, 'ordershow']);
Route::put('orderupdate/{id}', [OrderController::class, 'orderupdate']);
Route::delete('orderdelete/{id}', [OrderController::class, 'orderdelete']);
Route::post('canselOrder', [OrderController::class, 'canselOrder']);

Route::post('orderdetailSave', [OrderDetailController::class, 'orderdetailSave']);
Route::get('orderdetailshow/{id}', [OrderDetailController::class, 'orderdetailshow']);
Route::put('orderdetailupdate/{id}', [OrderDetailController::class, 'orderdetailupdate']);
Route::delete('orderdetaildelete/{id}', [OrderDetailController::class, 'orderdetaildelete']);

Route::post('SellerOrderSave', [SellerOrderController::class, 'SellerOrderSave']);
Route::get('SellerOrdershow/{id}', [SellerOrderController::class, 'SellerOrdershow']);

Route::post('DeleveryOrderSave', [DeleveryOrderController::class, 'DeleveryOrderSave']);
Route::get('DeleveryOrdershow/{id}', [DeleveryOrderController::class, 'DeleveryOrdershow']);
Route::get('selleramount/{id}', [DeleveryOrderController::class, 'selleramount']);
Route::get('rideramount/{id}', [DeleveryOrderController::class, 'rideramount']);
Route::get('sellerorders/{id}', [DeleveryOrderController::class, 'sellerorders']);
Route::get('riderorders/{id}', [DeleveryOrderController::class, 'riderorders']);

Route::get('selleraddchart/{id}', [DeleveryOrderController::class, 'selleraddchart']);
Route::get('rideraddchart/{id}', [DeleveryOrderController::class, 'rideraddchart']);

Route::post('postadvertisementSave', [PostAdvertisementsController::class, 'postadvertisementSave']);
Route::get('postadvertisementshow/{id}', [PostAdvertisementsController::class, 'postadvertisementshow']);
Route::put('postadvertisementupdate/{id}', [PostAdvertisementsController::class, 'postadvertisementupdate']);
Route::delete('postadvertisementdelete/{id}', [PostAdvertisementsController::class, 'postadvertisementdelete']);

Route::post('notificationSave', [NotificationController::class, 'notificationSave']);
Route::get('notificationshow/{id}', [NotificationController::class, 'notificationshow']);
Route::put('notificationupdate/{id}', [NotificationController::class, 'notificationupdate']);


Route::get('/test', function () {
    return response()->json([
        'message'=>'successs'
    ],200);
})->middleware('auth:api');
