<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatSellersTable extends Migration
{
    /**
     * Run the migrations.
     *sellers
     * @return void
     */
    public function up()
    {
        Schema::create(
            '',
            function (Blueprint $table) {
                $table->increments('id')->unique();
                $table->integer('seller_id');
                $table->date('join_date');
                $table->double('rate');
                $table->string('status');
                // $table->foreign('seller_id')->references('id')->on('users')->onDelete('cascade');
                $table->timestamps();
            }
        );
        // Schema::table('sellers',function (Blueprint $table){
        //         $table->foreign('seller_id')->references('id')->on('users')->onDelete('cascade');
        // });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sellers');

    }
}
