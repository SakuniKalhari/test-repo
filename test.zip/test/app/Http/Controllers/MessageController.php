<?php

namespace App\Http\Controllers;

use App\Models\Message;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MessageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function __construct()
    {
        //
        $this->middleware('auth:api', ['except' => ['savemessage', 'showmessage', 'updatemessage', 'deletemessage']]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function savemessage(Request $request)
    {
        $data = $request->only('sending_date', 'content', 'topic', 'email', 'sender_name');
        $validator = Validator::make($data, [
            'sending_date' => 'required|string',
            'content' => 'required|string',
            'topic' => 'required|string',
            'email' => 'required|string',
            'sender_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $bankdetail = Message::create([
            'sending_date' => $request->sending_date,
            'content' => $request->content,
            'topic' => $request->topic,
            'email' => $request->email,
            'sender_name' => $request->sender_name,
        ]);

        return response()->json([
            'code' => '200',
            'result' => $bankdetail
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showmessage($id)
    {
        $data=Message::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updatemessage(Request $request, $id)
    {
        $data = $request->only('sending_date', 'content', 'topic', 'email', 'sender_name');
        $std = Message::find($id);
         $std->update([
            'sending_date' => $request->sending_date,
            'content' => $request->content,
            'topic' => $request->topic,
            'email' => $request->email,
            'sender_name' => $request->sender_name,
         ]);
        // return $std;
        return response()->json([
            'code' => '203',
            'result' => 'Update Sucessfully'
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deletemessage($id)
    {
        $data=Message::where('id',$id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete Message Sucessfully'
        ], 201);
    }
}
