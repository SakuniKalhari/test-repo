<?php

namespace App\Http\Controllers;

use App\Models\OrderDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class OrderDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['orderdetailSave', 'orderdetailshow', 'orderdetailupdate', 'orderdetaildelete']]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function orderdetailSave(Request $request)
    {
        $data = $request->only('order_id', 'item_id', 'quntity');
        $validator = Validator::make($data, [
            'order_id' => 'required|integer',
            'item_id' => 'required|integer',
            'quntity' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $order = OrderDetail::create([
            'order_id' => $request->order_id,
            'item_id' => $request->item_id,
            'quntity' => $request->quntity,
        ]);

        return response()->json([
            'code' => '200',
            'result' => $order
        ], 201);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function orderdetailshow($id)
    {
        $data = OrderDetail::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function orderdetailupdate(Request $request, $id)
    {
        $data = $request->only('order_id', 'item_id', 'quntity');
        $std = OrderDetail::find($id);
        $std->update([
            'order_id' => $request->order_id,
            'item_id' => $request->item_id,
            'quntity' => $request->quntity,
        ]);
        return response()->json([
            'code' => '203',
            'result' => 'Update Sucessfully'
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function orderdetaildelete($id)
    {
        $data = OrderDetail::where('id', $id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete Sucessfully'
        ], 201);
    }
}
