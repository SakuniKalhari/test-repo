<?php

namespace App\Http\Controllers;

use App\Models\Ads;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AdsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function __construct()
    {
        //
        $this->middleware('auth:api', ['except' => ['adsSave', 'adsshow', 'adsupdate', 'adsdelete']]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function adsSave(Request $request)
    {
        $data = $request->only('Date_created', 'main_photo', 'Address');
        $validator = Validator::make($data, [
            'Date_created' => 'required|string',
            'main_photo' => 'required|image|mimes:jpeg,png,jpg',
            'Address' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $image_save_path = $request->file('main_photo')->store('public/upload');
        $image_save_path = str_replace('public', 'storage', $image_save_path);

        $section = Ads::create([
            'Date_created' => $request->Date_created,
            'main_photo' => $image_save_path,
            'Address' => $request->Address,
        ]);

        $section->main_photo = url($section->main_photo);

        return response()->json([
            'code' => '200',
            'result' => $section
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function adsshow($id)
    {
        $data= Ads::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function adsupdate(Request $request, $id)
    {
        $image_save_path = $request->file('main_photo')->store('public/upload');
        $image_save_path = str_replace('public', 'storage', $image_save_path);

        $data = $request->only('Date_created', 'main_photo', 'Address');
        $std = Ads::find($id);
        $std->update([
            'Date_created' => $request->Date_created,
            'main_photo' => $image_save_path,
            'Address' => $request->Address,
        ]);

        return response()->json([
            'code' => '200',
            'result' => 'Update Sucessfully'
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function adsdelete($id)
    {
        $data=Ads::where('id',$id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete Ad Sucessfully'
        ], 201);
    }
}
