<?php

namespace App\Http\Controllers;

use App\Models\Rider;
use App\Models\Seller;
use JWTAuth;
use App\Models\User;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Exceptions\JWTException;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Validator;

class ApiController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['authenticate', 'register']]);
    }

    //
    public function register(Request $request)
    {
        // dd($request->all());
        //Validate data
        $data = $request->only('name', 'email', 'mobile_number', 'address', 'role','password', 'password_confirmation');
        $validator = Validator::make($data, [
            'name' => 'required|string',
            'email' => 'required|email|unique:users',
            'mobile_number' => 'required|string|unique:users',
            'address' => 'required|string',
            'role' => 'required|string',
            'password' => 'required|string|min:6|max:50|confirmed'
        ]);

        // Send failed response if request is not valid
        if ($validator->fails()) {
            return response()->json(['code' => 400, 'error' => $validator->errors()->toJson()], 400);
        }

        //Request is valid, create new user
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'mobile_number' => $request->mobile_number,
            'address' => $request->address,
            'role' => $request->role,
            'password' => bcrypt($request->password)
        ]);

        $user->image = url($user->image);


        if($user->role=='rider'){
            $rid = Rider::create([
                'rider_id' => $user->id,
                'status' => 'available',
                'rate_per_KM' => 0,
                'join_date' => '2555',
            ]);
        }
        if ($user->role == 'seller') {
            $sel = Seller::create([
                'seller_id' => $user->id,
                'join_date' => '2020-05-02',
                'rate' => 0,
                'status' => true,
            ]);
        }
        return response()->json([
            'code'=>201,
            'result' =>[
                'message' => 'registation successfully',
                'user' => $user
            ],
        ], 201);
    }

    public function authenticate(Request $request)
    {
        $credentials = $request->only('mobile_number', 'password');

        //valid credential
        $validator = Validator::make($credentials, [
            'mobile_number' => 'required|string',
            'password' => 'required|string|min:6|max:50'
        ]);

        //Send failed response if request is not valid
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()->toJson()], 200);
        }

        //Request is validated
        //Crean token
        try {
            if (!$token = auth()->attempt($validator->validated())) {
                return response()->json(['error' => 'Unauthorized'], 401);
            }

            return response()->json([
                'access_token' => $token,
                'token_type' => 'bearer',
                'expires_in' => auth()->factory()->getTTL() * 60,
                'user' => auth()->user()
            ],200);

        } catch (JWTException $e) {
            return $credentials;
            return response()->json([
                'success' => false,
                'message' => 'Could not create token.',
            ], 500);
        }
    }

    public function logout(Request $request)
    {
        //valid credential
        $validator = Validator::make($request->only('token'), [
            'token' => 'required'
        ]);

        //Send failed response if request is not valid
        if ($validator->fails()) {
            return response()->json(['error' => $validator->messages()], 200);
        }

        //Request is validated, do logout
        try {
            JWTAuth::invalidate($request->token);

            return response()->json([
                'success' => true,
                'message' => 'User has been logged out'
            ]);
        } catch (JWTException $exception) {
            return response()->json([
                'success' => false,
                'message' => 'Sorry, user cannot be logged out'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function get_user(Request $request)
    {
        $this->validate($request, [
            'token' => 'required'
        ]);

        $user = JWTAuth::authenticate($request->token);

        return response()->json(['user' => $user]);
    }
}
