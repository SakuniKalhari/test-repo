<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\Rider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['orderSave', 'ordershow', 'orderupdate', 'orderdelete', 'canselOrder']]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function orderSave(Request $request)
    {
        $data = $request->only('customer_id', 'seller_id', 'rider_id', 'order_id', 'order_date');
        $validator = Validator::make($data, [
            'customer_id' => 'required|integer',
            'seller_id' => 'required|integer',
            'rider_id' => 'required|integer',
            'order_id' => 'required|integer',
            'order_date' => 'required|date',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }
        $ride = DB::table('riders')->where('status', 'available')->first();

        $order = Order::create([
            'customer_id' => $request->customer_id,
            'seller_id' => $request->seller_id,
            'rider_id' => $ride->rider_id,
            'order_id' => $request->order_id,
            'order_date' => '2020-05-02',
        ]);

        $order = OrderDetail::create([
            'order_id' => $order->id,
            'item_id' => 2,
            'quntity' => 5,
        ]);

        return response()->json([
            'code' => '200',
            'result' => $order
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function ordershow($id)
    {
        $data = Order::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function orderupdate(Request $request, $id)
    {

        $data = $request->only('customer_id', 'seller_id', 'rider_id', 'order_id', 'order_date');
        $std = Order::find($id);
        $std->update([
            'customer_id' => $request->customer_id,
            'seller_id' => $request->seller_id,
            'rider_id' => $request->rider_id,
            'order_id' => $request->order_id,
            'order_date' => '2020-05-02',
        ]);
        return response()->json([
            'code' => '203',
            'result' => 'Update Order Sucessfully'
        ], 201);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function orderdelete($id)
    {
        $data = Order::where('id', $id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete Order Sucessfully'
        ], 201);
    }

    public function canselOrder(Request $request)
    {
        DB::table('riders')->where('rider_id', $request->rider_id)->update(array('status'=>'notavailable'));
        $ride = DB::table('riders')->where('status', 'available')->first();

        $order = Order::create([
            'customer_id' => $request->customer_id,
            'seller_id' => $request->seller_id,
            'rider_id' => $ride->rider_id,
            'order_id' => $request->order_id,
            'order_date' => '2020-05-02',
        ]);
        return response()->json([
            'code' => '203',
            'result' => 'Cancel Sucessfully'
        ], 201);
    }
}
