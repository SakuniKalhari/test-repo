<?php

namespace App\Http\Controllers;

use App\Models\Review;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ReviewController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function __construct()
    {
        //
        $this->middleware('auth:api', ['except' => ['savereview', 'showreview', 'updatereview', 'deletereview']]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function savereview(Request $request)
    {
        $data = $request->only('user_id', 'rate', 'message', 'date');
        $validator = Validator::make($data, [
            'user_id' => 'required|integer',
            'rate' => 'required|string',
            'message' => 'required|string',
            'date' => 'required|date',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $que = Review::create([
            'user_id' => $request->user_id,
            'rate' => $request->rate,
            'message' => $request->message,
            'date' => $request->date,
        ]);
        return response()->json([
            'code' => '200',
            'result' => $que
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showreview($id)
    {
        $data = Review::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updatereview(Request $request, $id)
    {
        $data = $request->only('user_id', 'rate', 'message', 'date');
        $std = Review::find($id);
        $std->update([
            'user_id' => $request->user_id,
            'rate' => $request->rate,
            'message' => $request->message,
            'date' => $request->date,
        ]);

        return response()->json([
            'code' => '200',
            'result' => 'Update Sucessfully'
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deletereview($id)
    {
        $data = Review::where('id', $id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete Sucessfully'
        ], 201);
    }
}
