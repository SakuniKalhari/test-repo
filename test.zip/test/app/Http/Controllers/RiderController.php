<?php

namespace App\Http\Controllers;

use App\Models\Rider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class RiderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function __construct()
    {
        //
        $this->middleware('auth:api', ['except' => ['saverider', 'showstatus', 'updaterider']]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function saverider(Request $request)
    {
        $data = $request->only('rider_id', 'status', 'rate_per_KM', 'join_date');
        $validator = Validator::make($data, [
            'rider_id' => 'required|string',
            'status' => 'required|string',
            'rate_per_KM' => 'required|string',
            'join_date' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $que = Rider::create([
            'rider_id' => $request->rider_id,
            'status' => $request->status,
            'rate_per_KM' => $request->rate_per_KM,
            'join_date' => $request->join_date,
        ]);
        return response()->json([
            'code' => '200',
            'result' => $que
        ], 201);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showstatus($id)
    {
        $data = Rider::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updaterider(Request $request, $id)
    {
        $data = $request->only('rider_id', 'status', 'rate_per_KM', 'join_date');
        $std = Rider::find($id);
        $std->update([
            'rider_id' => $request->rider_id,
            'status' => $request->status,
            'rate_per_KM' => $request->rate_per_KM,
            'join_date' => $request->join_date,
        ]);

        return response()->json([
            'code' => '200',
            'result' => 'Update Sucessfully'
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
