<?php

namespace App\Http\Controllers;

use JWTAuth;
use App\Models\Section;
use Tymon\JWTAuth\Exceptions\JWTException;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Validator;

class SectionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        //
        $this->middleware('auth:api', ['except' => ['sectionSave', 'sectionshow', 'sectionupdate', 'sectiondelete']]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function sectionSave(Request $request)
    {
        $data = $request->only('title', 'image', 'discription');
        // $image= $request->file('image');
        $validator = Validator::make($data, [
            'title' => 'required|string',
            'image' => 'required|image|mimes:jpeg,png,jpg',
            'discription' => 'required|string',
            // 'isactive' => 'required|boolean',

        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $image_save_path = $request->file('image')->store('public/upload');
        // $image_path = substr($image_save_path, strpos($image_save_path, "/") + 1);
        $image_save_path=str_replace('public','storage',$image_save_path);

        $section = Section::create([
            'title' => $request->title,
            'image' => $image_save_path,
            'discription' => $request->discription,
            'isactive' => true
        ]);

        $section->image=url($section->image);

        return response()->json([
            'code' => '200',
            'result' => $section
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function sectionshow($id)
    {
        $data= Section::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' =>$data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function sectionupdate(Request $request, $id)
    {
        //
        $std = Section::find($id);
        $std->update($request->all());
        return $std;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function sectiondelete($id)
    {
        $data=Section::where('id',$id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete Section Sucessfully'
        ], 201);
    }
}
