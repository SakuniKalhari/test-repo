<?php

namespace App\Http\Controllers;

use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class NotificationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['notificationSave', 'notificationshow', 'notificationupdate']]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function notificationSave(Request $request)
    {
        $data = $request->only('user_id','title', 'image', 'discription');
        $validator = Validator::make($data, [
            'user_id' => 'required|string',
            'title' => 'required|string',
            'image' => 'required|image|mimes:jpeg,png,jpg',
            'discription' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $image_save_path = $request->file('image')->store('public/upload');
        $image_save_path = str_replace('public', 'storage', $image_save_path);

        $section = Notification::create([
            'user_id' => $request->user_id,
            'title' => $request->title,
            'image' => $image_save_path,
            'discription' => $request->discription,
        ]);

        $section->image = url($section->image);

        return response()->json([
            'code' => '200',
            'result' => $section
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function notificationshow($id)
    {
        $data = Notification::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function notificationupdate(Request $request, $id)
    {
        $image_save_path = $request->file('image')->store('public/upload');
        $image_save_path = str_replace('public', 'storage', $image_save_path);

        $data = $request->only('user_id','title', 'image', 'discription');
        $std = Notification::find($id);
        $std->update([
            'user_id' => $request->user_id,
            'title' => $request->title,
            'image' => $image_save_path,
            'discription' => $request->discription,
        ]);

        return response()->json([
            'code' => '200',
            'result' => 'Update Sucessfully'
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
