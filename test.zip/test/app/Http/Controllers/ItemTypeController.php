<?php

namespace App\Http\Controllers;

use App\Models\ItemType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ItemTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function __construct()
    {
        //
        $this->middleware('auth:api', ['except' => ['ItemTypeSave', 'ItemTypeshow', 'ItemTypeupdate', 'ItemTypedelete']]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function ItemTypeSave(Request $request)
    {
        $data = $request->only('image', 'discription','title');
        $validator = Validator::make($data, [
            'image' => 'required|image|mimes:jpeg,png,jpg',
            'discription' => 'required|string',
            'title' => 'required|string',
            // 'isactive' => 'required|boolean',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $image_save_path = $request->file('image')->store('public/upload');
        $image_save_path = str_replace('public', 'storage', $image_save_path);

        $section = ItemType::create([
            'image' => $image_save_path,
            'discription' => $request->discription,
            'title' => $request->title,
            'isactive' => true
        ]);

        $section->image = url($section->image);

        return response()->json([
            'code' => '200',
            'result' => $section
        ], 201);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function ItemTypeshow($id)
    {
        $data = ItemType::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function ItemTypeupdate(Request $request, $id)
    {
        $image_save_path = $request->file('image')->store('public/upload');
        $image_save_path = str_replace('public', 'storage', $image_save_path);

        $data = $request->only('image', 'discription', 'title','isactive');
        $std = ItemType::find($id);
        $std->update([
            'image' => $image_save_path,
            'discription' => $request->discription,
            'title' => $request->title,
            'isactive' => true
        ]);
        return response()->json([
            'code' => '203',
            'result' => 'Update Sucessfully'
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function ItemTypedelete($id)
    {
        $data = ItemType::where('id', $id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete Sucessfully'
        ], 201);
    }
}
