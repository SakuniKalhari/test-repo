<?php

namespace App\Http\Controllers;

use App\Models\Question;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class QuestionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function __construct()
    {
        //
        $this->middleware('auth:api', ['except' => ['saveQuestion', 'showQuestion', 'updateQuestion', 'deleteQuestion']]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     *
     */
    public function saveQuestion(Request $request)
    {
        $data = $request->only('user_id', 'question');
        $validator = Validator::make($data, [
            'user_id' => 'required|integer',
            'question' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $que = Question::create([
            'user_id' => $request->user_id,
            'question' => $request->question,
        ]);
        return response()->json([
            'code' => '200',
            'result' => $que
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showQuestion($id)
    {
        $data = Question::find($id);
        if (!$data){
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateQuestion(Request $request, $id)
    {
        $data = $request->only('user_id', 'question');
        $std = Question::find($id);
        $std->update([
            'user_id' => $request->user_id,
            'question' => $request->question,
        ]);
        return response()->json([
            'code' => '203',
            'result' => 'Update Question Sucessfully'
        ], 201);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteQuestion($id)
    {
        $data=Question::where('id',$id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete Question Successfully'
        ], 201);
    }
}
