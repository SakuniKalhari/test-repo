<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function __construct()
    {
        //
        $this->middleware('auth:api', ['except' => ['saveSetting', 'showSetting', 'updateSetting', 'deleteSetting']]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function saveSetting(Request $request)
    {
        $data = $request->only('icon', 'logo', 'email', 'page_bottom_discription', 'terms_conditions', 'number_of_ads_home_page','commission_latter');
        $validator = Validator::make($data, [
            'icon' => 'required|image|mimes:jpeg,png,jpg',
            'logo'  => 'required|image|mimes:jpeg,png,jpg',
            'email' => 'required|string',
            'page_bottom_discription' => 'required|string',
            'terms_conditions' => 'required|string',
            'number_of_ads_home_page' => 'required|integer',
            'commission_latter' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $image_save_path = $request->file('icon')->store('public/upload');
        $image_save_path = $request->file('logo')->store('public/upload');
        $image_save_path = str_replace('public', 'storage', $image_save_path);

        $setting = Setting::create([
            'icon' => $image_save_path,
            'logo' => $image_save_path,
            'email' =>$request->email,
            'page_bottom_discription' => $request->page_bottom_discription,
            'terms_conditions' => $request->terms_conditions,
            'number_of_ads_home_page' =>$request->number_of_ads_home_page,
            'commission_latter' => $request->commission_latter
        ]);

        $setting->icon = url($setting->icon);
        $setting->logo = url($setting->logo);

        return response()->json([
            'code' => '200',
            'result' => $setting
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showSetting($id)
    {
        $data = Setting::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateSetting(Request $request, $id)
    {
        $image_save_path = $request->file('icon')->store('public/upload');
        $image_save_path = $request->file('logo')->store('public/upload');
        $image_save_path = str_replace('public', 'storage', $image_save_path);

        $data = $request->only('icon', 'logo', 'email', 'page_bottom_discription', 'terms_conditions', 'number_of_ads_home_page', 'commission_latter');
        $std = Setting::find($id);
        $std->update([
            'icon' => $image_save_path,
            'logo' => $image_save_path,
            'email' => $request->email,
            'page_bottom_discription' => $request->page_bottom_discription,
            'terms_conditions' => $request->terms_conditions,
            'number_of_ads_home_page' => $request->number_of_ads_home_page,
            'commission_latter' => $request->commission_latter
        ]);
        return response()->json([
            'code' => '203',
            'result' => 'Update Setting Sucessfully'
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteSetting($id)
    {
        $data=Setting::where('id',$id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete Setting Successfully'
        ], 201);
    }
}
