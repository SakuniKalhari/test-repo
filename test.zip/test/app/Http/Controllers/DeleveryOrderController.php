<?php

namespace App\Http\Controllers;

use App\Models\DeleveryOrder;
use App\Models\Order;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use PHPUnit\TextUI\XmlConfiguration\Group;
use Symfony\Component\VarDumper\Cloner\Data;

class DeleveryOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['DeleveryOrderSave', 'DeleveryOrdershow',
           'Deleveryupdate', 'selleraddchart', 'rideraddchart', 'selleramount', 'rideramount',
            'sellerorders', 'riderorders']]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function DeleveryOrderSave(Request $request)
    {
        $data = $request->only('earn_amount','order_id');
        $validator = Validator::make($data, [
            'earn_amount' => 'required|string',
            'order_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $section = DeleveryOrder::create([
            'earn_amount' => $request->earn_amount,
            'order_id' => $request->order_id,
        ]);

        return response()->json([
            'code' => '200',
            'result' => $section
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function DeleveryOrdershow($id)
    {
        $data = DeleveryOrder::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function selleraddchart(Request $request ,$id)
    {
        $data = DB::select("SELECT date(`created_at`) as `date`,count(*) as order_count FROM `orders` WHERE  `seller_id` = " . $id . " AND week(`created_at`) = week(now()) GROUP BY date(`created_at`)");
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ]);
    }

    public function rideraddchart(Request $request, $id)
    {
        $data = DB::select("SELECT date(`created_at`) as `date`,count(*) as order_count FROM `orders` WHERE  `rider_id` = ". $id ." AND week(`created_at`) = week(now()) GROUP BY date(`created_at`)");
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ]);
    }

    public function selleramount(Request $request, $id)
    {
        $data =  DB::table('sellerorders')->sum('seller_amount');
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ]);
    }

    public function rideramount(Request $request, $data)
    {
        $data = DB::table('deleveryorders')->sum('earn_amount');
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ]);
    }

    public function sellerorders(Request $request, $id)
    {
        return DB::table('sellerorders')->sum('order_id');
    }

    public function riderorders(Request $request, $data)
    {
        return DB::table('deleveryorders')->get('order_id');
    }
}
