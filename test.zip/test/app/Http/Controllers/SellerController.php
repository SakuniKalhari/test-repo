<?php

namespace App\Http\Controllers;

use App\Models\Seller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SellerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function __construct()
    {
        //
        $this->middleware('auth:api', ['except' => ['SellerSave', 'Sellershow', 'Sellerupdate', 'Sellerdelete']]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function SellerSave(Request $request)
    {
        $data = $request->only('seller_id', 'join_date', 'rate');
        $validator = Validator::make($data, [
            'seller_id' => 'required|string',
            'join_date' => 'required|string',
            'rate' => 'required|string',
            // 'status' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $section = Seller::create([
            'seller_id' => $request->seller_id,
            'join_date' => $request->join_date,
            'rate' => $request->rate,
            'status' => true,
        ]);

        return response()->json([
            'code' => '200',
            'result' => $section
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function Sellershow($id)
    {
        $data = Seller::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function Sellerupdate(Request $request, $id)
    {
        $data = $request->only('seller_id', 'join_date', 'rate','status');
        $std = Seller::find($id);
        $std->update([
            'seller_id' => $request->seller_id,
            'join_date' => $request->join_date,
            'rate' => $request->rate,
            'status' => true,
        ]);
        return response()->json([
            'code' => '203',
            'result' => 'Update Seller Sucessfully'
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function Sellerdelete($id)
    {
        $data = Seller::where('id', $id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete Seller Successfully'
        ], 201);
    }
}
