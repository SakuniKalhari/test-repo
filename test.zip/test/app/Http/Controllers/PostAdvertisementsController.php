<?php

namespace App\Http\Controllers;

use App\Models\PostAdvertisements;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PostAdvertisementsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function __construct()
    {
        //
        $this->middleware('auth:api', ['except' => ['postadvertisementSave', 'postadvertisementshow', 'postadvertisementupdate', 'postadvertisementdelete']]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function postadvertisementSave(Request $request)
    {
        $data = $request->only('ad_title', 'picture', 'discription');
        $validator = Validator::make($data, [
            'ad_title' => 'required|string',
            'picture' => 'required|image|mimes:jpeg,png,jpg',
            'discription' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $image_save_path = $request->file('picture')->store('public/upload');
        $image_save_path = str_replace('public', 'storage', $image_save_path);

        $section = PostAdvertisements::create([
            'ad_title' => $request->ad_title,
            'picture' => $image_save_path,
            'discription' => $request->discription,
        ]);

        $section->picture = url($section->picture);

        return response()->json([
            'code' => '200',
            'result' => $section
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function postadvertisementshow($id)
    {
        $data = PostAdvertisements::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function postadvertisementupdate(Request $request, $id)
    {
        $image_save_path = $request->file('picture')->store('public/upload');
        $image_save_path = str_replace('public', 'storage', $image_save_path);

        $data = $request->only('ad_title', 'picture', 'discription');
        $std = PostAdvertisements::find($id);
        $std->update([
            'ad_title' => $request->ad_title,
            'picture' => $image_save_path,
            'discription' => $request->discription,
        ]);

        return response()->json([
            'code' => '200',
            'result' => 'Update Sucessfully'
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function postadvertisementdelete($id)
    {
        $data = PostAdvertisements::where('id', $id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete Sucessfully'
        ], 201);
    }
}
