<?php

namespace App\Http\Controllers;

use App\Models\BankDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BankDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function __construct()
    {
        //
        $this->middleware('auth:api', ['except' => ['saveBankdetail', 'showbankdetail', 'updatebankdetail', 'deletebankdetail']]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function saveBankdetail(Request $request)
    {
        $data = $request->only('date_created', 'iBAN_number','account_number', 'beneficiary_name', 'bank_name');
        $validator = Validator::make($data, [
            'date_created' => 'required|string',
            'iBAN_number' => 'required|integer',
            'account_number' => 'required|integer',
            'beneficiary_name' =>'required|string',
            'bank_name' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $bankdetail = BankDetail::create([
            'date_created' => $request->date_created,
            'iBAN_number' => $request->iBAN_number,
            'account_number' => $request->account_number,
            'beneficiary_name' => $request->beneficiary_name,
            'bank_name' => $request->bank_name,
        ]);

        return response()->json([
            'code' => '200',
            'result' => $bankdetail
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showbankdetail($id)
    {
        $data= BankDetail::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updatebankdetail(Request $request, $id)
    {
        $data = $request->only('date_created','iBAN_number','account_number', 'beneficiary_name', 'bank_name');
        $std = BankDetail::find($id);
        $std->update([
            'date_created'=>$request->date_created,
            'iBAN_number'=>$request->iBAN_number,
            'account_number'=> $request->account_number,
            'beneficiary_name' => $request->beneficiary_name,
            'bank_name'=> $request->bank_name,
        ]);
        return response()->json([
            'code' => '203',
            'result' => 'Update Sucessfully'
        ], 201);    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deletebankdetail($id)
    {
        $data=BankDetail::where('id',$id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete BankDetail Sucessfully'
        ], 201);
    }
}
