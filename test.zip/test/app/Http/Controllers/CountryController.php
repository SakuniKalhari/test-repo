<?php

namespace App\Http\Controllers;

use App\Models\Country;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;


class CountryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function __construct()
    {
        //
        $this->middleware('auth:api', ['except' => ['saveCountry', 'showCountry', 'updateCountry', 'deleteCountry']]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function saveCountry(Request $request)
    {
        //
        $data = $request->only('date_created', 'country', 'city');
        $validator = Validator::make($data, [
            'date_created' => 'required|string',
            'country' => 'required|string',
            'city' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['code' => '500', 'error' => 'null'], 200);
        }

        $country = Country::create([
            'date_created' => $request->date_created,
            'country' => $request->country,
            'city' => $request->city
        ]);

        return response()->json([
            'code' => '200',
            'result' => $country
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showCountry($id)
    {
        $data=Country::find($id);
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '200',
            'result' => $data
        ], 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateCountry(Request $request, $id)
    {
        $data = $request->only('date_created', 'country', 'city');
        $std = Country::find($id);
        $std->update([
            'date_created' => $request->date_created,
            'country' => $request->country,
            'city' => $request->city
        ]);
        // return $std;
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Update Country Sucessfully'
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteCountry($id)
    {
        $data=Country::where('id',$id)->delete();
        if (!$data) {
            return response()->json([
                'code' => '500',
                'result' => $data
            ]);
        }
        return response()->json([
            'code' => '203',
            'result' => 'Delete Country Successfully'
        ], 201);
    }
}
