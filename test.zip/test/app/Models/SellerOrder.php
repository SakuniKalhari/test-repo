<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class SellerOrder extends Model
{
    use HasFactory,Notifiable;

    protected $table = 'sellerOrders';
    protected $fillable = [
        'commition_rate',
        'seller_amount',
        'orderid',
    ];
}
