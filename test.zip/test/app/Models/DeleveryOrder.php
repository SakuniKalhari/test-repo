<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class DeleveryOrder extends Model
{
    use HasFactory,Notifiable;

    protected $table = 'deleveryOrders';
    protected $fillable = [
        'earn_amount',
        'order_id',
    ];
}
