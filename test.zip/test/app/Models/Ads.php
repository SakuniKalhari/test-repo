<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class Ads extends Model
{
    use HasFactory,Notifiable;
        protected $table = 'ads';
        protected $fillable = [
        'Date_created',
        'main_photo',
        'Address'
        ];
}
