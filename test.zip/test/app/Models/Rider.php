<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class Rider extends Model
{
    use HasFactory,Notifiable;

    protected $table = 'riders';

    protected $fillable = [
        'rider_id',
        'status',
        'rate_per_KM',
        'join_date',
    ];
}
