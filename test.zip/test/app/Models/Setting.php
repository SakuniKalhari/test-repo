<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class Setting extends Model
{
    use HasFactory, Notifiable;
    protected $table = 'settings';
    protected $fillable = [
        'icon',
        'logo',
        'email',
        'page_bottom_discription',
        'terms_conditions',
        'number_of_ads_home_page',
        'commission_latter',
    ];
}
