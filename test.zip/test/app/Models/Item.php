<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class Item extends Model
{
    use HasFactory,Notifiable;

    protected $table = 'items';

    protected $fillable = [
        'title',
        'picture',
        'product_price',
        'itemType_id',
        'seller_id',
    ];
}
